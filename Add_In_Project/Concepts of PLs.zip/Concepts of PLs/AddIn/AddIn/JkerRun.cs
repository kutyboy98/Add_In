﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddIn.Model.Forms;
using AddIn.Model.ThisProject;
using AddIn.Support;
using System.IO;

namespace AddIn
{
    public partial class JkerRun : Form
    {
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }
        public JkerRun()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            pb_restore.Image = Image.FromFile(rbgColor.btnResizeImg);            
        }

        private void clickNew(object sender, EventArgs e)
        {
            settingNewPage();              
        }
        private void settingNewPage(string newName = null,string pathStr = null, string content="")
        {
            if (newName == null)
            {
                newName = checkName();
                pathStr = newName;
            }
            if(newName!=null)
            {
                Page NewPage = new Page();
                NewPage.NameNotEdit = newName;
                NewPage.NameEdit = newName + " *";
                if (!pathStr.Contains("\\"))
                {
                    NewPage.Text = NewPage.NameEdit;
                    NewPage.isEdit = true;
                }                    
                else
                {
                    NewPage.Text = NewPage.NameNotEdit;
                    NewPage.isEdit = false;
                }                    
                NewPage.Path = pathStr;
                NewPage.tb_content.Text = content;
                NewPage.MdiParent = this;
                NewPage.Show();
                //set name lb_current
                lb_current_page.Text = NewPage.Path;
            }
        }
        private string checkName()
        {
            if (MdiChildren.Count() <= 0)
            {
                return "New 1";                
            }
            else
            {
                int have = 0;
                for (int i = 1; i < 20; i++)
                {
                    foreach (var item in MdiChildren)
                    {
                        if (item.Text.Replace("*","").Trim().Equals("New " + i.ToString()) == true)
                        {
                            have = 1;
                            break;
                        }
                        have = 0;
                    }
                    if (have == 0)
                        return "New " + i.ToString();
                }
            }
            return null;
        }
        private void keyDown(object sender, KeyEventArgs e)
        {
            if(e.Control && e.KeyCode == Keys.N)
            {
                settingNewPage();
            }
        }

        private void choicePage(object sender, MouseEventArgs e)
        {
            try { 
                Page p = (Page)ActiveMdiChild;
                lb_current_page.Text = p.Path;
            }catch(Exception ex)
            {
                lb_current_page.Text = "Jker Text.txt";
            }
        }

        private void moveClose(object sender, MouseEventArgs e)
        {
            rbgColor.setPictureBox(pb_close, 228, 228, 228);            

        }

        private void leaveClose(object sender, EventArgs e)
        {
            pb_close.BackColor = Color.Transparent;            
        }

        private void moveMinize(object sender, MouseEventArgs e)
        {
            rbgColor.setPictureBox(pb_minimize, 228, 228, 228);
        }

        private void leaveMinize(object sender, EventArgs e)
        {
            pb_minimize.BackColor = Color.Transparent;            
        }

        private void moveRestore(object sender, MouseEventArgs e)
        {
            rbgColor.setPictureBox(pb_restore, 228, 228, 228);
        }

        private void leaveRestore(object sender, EventArgs e)
        {
            pb_restore.BackColor = Color.Transparent;
        }

        private void clickClose(object sender, EventArgs e)
        {
            if(MdiChildren.Count()>0)
            {
                foreach (var item in MdiChildren)
                {
                    if(item.Text.Contains("*"))
                    {
                        DialogResult dialogResult = MessageBox.Show("Bạn có muốn lưu "+ item.Text.Replace("*","").Trim()+"?","Jker NotePad" , MessageBoxButtons.YesNoCancel);
                        if (dialogResult == DialogResult.Yes)
                        {
                            settingSave((Page)item);
                            
                        }
                        if (dialogResult == DialogResult.Cancel) { return; }
                    }
                }
                this.Close();
            }
            else
            {
                this.Close();
            }
        }

        private void clickRestore(object sender, EventArgs e)
        {
            if (this.WindowState != FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Maximized;
                pb_restore.Image = Image.FromFile(rbgColor.btnResizeImg);                
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
                pb_restore.Image = Image.FromFile(rbgColor.btnMaximineImg);
            }
        }

        private void clickMinimine(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void clickOpenText(object sender, EventArgs e)
        {
            using (OpenFileDialog folder = new OpenFileDialog() { Filter = "Text Document | *.txt", ValidateNames = true, Multiselect = false })
            {
                if (folder.ShowDialog() == DialogResult.OK)
                {
                    using (StreamReader sr = new StreamReader(folder.FileName))
                    {
                        Task<string> Text = sr.ReadToEndAsync();
                        settingNewPage(JkerStr.getName(folder.FileName), folder.FileName, Text.Result);
                    }
                }
            }
        }

        private void clickSave(object sender, EventArgs e)
        {
            settingSave();
        }
        private async void settingSave(Page p = null)
        {
            if(p==null)
                p = (Page)ActiveMdiChild;
            try
            {
                if (p.Path.Contains("\\"))
                {
                    using (StreamWriter sw = new StreamWriter(p.Path))
                    {
                        await sw.WriteLineAsync(p.TextContent);
                        p.Text = p.NameNotEdit;
                        p.isEdit = false;
                    }
                }
                else
                {
                    using (SaveFileDialog sfd = new SaveFileDialog { Filter = "Text Documents|*.txt", ValidateNames = true })
                    {
                        if (sfd.ShowDialog() == DialogResult.OK)
                        {
                            using (StreamWriter sw = new StreamWriter(sfd.FileName))
                            {
                                await sw.WriteLineAsync(p.TextContent);
                                p.Path = sfd.FileName;
                                p.NameNotEdit = JkerStr.getName(sfd.FileName);
                                p.NameEdit = p.NameNotEdit + " *";
                                p.Text = p.NameNotEdit;
                                p.isEdit = false;
                                lb_current_page.Text = p.Path;
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { }
        }

        private void closePage(object sender, DevExpress.XtraTabbedMdi.MdiTabPageEventArgs e)
        {
            Page p = (Page)e.Page.MdiChild;
            if(p.isEdit)
            {
                DialogResult dialogResult = MessageBox.Show("Bạn có muốn lưu " + p.NameNotEdit + "?", "Jker NotePad", MessageBoxButtons.YesNoCancel);
                if (dialogResult == DialogResult.Yes)
                {
                    p.tb_content.Text = p.TextContent;     
                    settingSave(p);
                }
            }         
        }

        private void clickUndo(object sender, EventArgs e)
        {
            try
            {
                Page p = (Page)ActiveMdiChild;
                p.callUndo();
            }catch(Exception ex) { }
        }

        private void clickRedo(object sender, EventArgs e)
        {
            try
            {
                Page p = (Page)ActiveMdiChild;
                p.callRedo();
            }
            catch (Exception ex) { }
        }

        private void clickCut(object sender, EventArgs e)
        {
            try
            {
                Page p = (Page)ActiveMdiChild;
                p.callCut();
            }
            catch (Exception ex) { }
        }

        private void clickCopy(object sender, EventArgs e)
        {
            try
            {
                Page p = (Page)ActiveMdiChild;
                p.callCopy();
            }
            catch (Exception ex) { }
        }

        private void clickPaste(object sender, EventArgs e)
        {
            try
            {
                Page p = (Page)ActiveMdiChild;
                p.callPaste();
            }
            catch (Exception ex) { }
        }

        private void clickSelectAll(object sender, EventArgs e)
        {
            try
            {
                Page p = (Page)ActiveMdiChild;
                p.callSelectAll();
            }
            catch (Exception ex) { }
        }

        private void clickFont(object sender, EventArgs e)
        {
            try
            {
                Page p = (Page)ActiveMdiChild;
                p.callFont();
            }
            catch (Exception ex) { }
        }

        private void clickColor(object sender, EventArgs e)
        {
            try
            {
                Page p = (Page)ActiveMdiChild;
                p.callColor();
            }
            catch (Exception ex) { }
        }

        private void clickFind(object sender, EventArgs e)
        {
            try
            {
                if(MdiChildren.Count()>0)
                {
                    Page p = (Page)ActiveMdiChild;
                    fp.p = p;                    
                    fp.Show(this);
                    fp.BringToFront();
                }
            }catch(Exception ex) { }
        }

        private void clickReplace(object sender, EventArgs e)
        {

        }
        FindPage fp = new FindPage();

        private void clickOpenPDF(object sender, EventArgs e)
        {

        }

        private void clickOpenHTML(object sender, EventArgs e)
        {

        }
    }
}
