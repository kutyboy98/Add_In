﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddIn.Model.ThisProject
{
    public class JkerStr
    {
        public int index { get; set; }
        public int length { get; set; }
        public static string getName(string path)
        {
            string Name = "";
            try
            {
                Name = path.Split('\\').LastOrDefault();
            }
            catch (Exception ex)
            {
                Name = path;
            }
            return Name;
        }
        public static List<JkerStr> arrIndexOf(string parrent,string value)
        {
            List<JkerStr> resultArr = new List<JkerStr>();
            for(int i=0;i<parrent.Length;i++)
            {                
                if(parrent[i]==value[0])
                {
                    int iTemp = i+1;
                    bool checkI = true;
                    for(int j=1;j<value.Length;j++)
                    {
                        try
                        {
                            if (value[j] != parrent[iTemp])
                            {
                                checkI = false;
                                break;
                            }
                            iTemp++;
                        }
                        catch(Exception e) { checkI = false;break; }
                    }
                    if(checkI==true)
                    {
                        resultArr.Add(new JkerStr {index=i,length = value.Length });
                    }
                }
            }
            return resultArr;
        }
    }
    public class JkerResult
    {
        public int serial { get; set; }
        public string value { get; set; }
        public bool isChoice { get; set; }
        public int indexInLine { get; set; }
        public int lengthInLine { get; set; }
    }        
}
