﻿using AddIn.Model.ThisProject;
using AddIn.Support;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddIn.Model.Forms
{
    public partial class FindPage : Form
    {
        #region shadow
        private bool Drag;
        private int MouseX;
        private int MouseY;

        private const int WM_NCHITTEST = 0x84;
        private const int HTCLIENT = 0x1;
        private const int HTCAPTION = 0x2;

        private bool m_aeroEnabled;

        private const int CS_DROPSHADOW = 0x00020000;
        private const int WM_NCPAINT = 0x0085;
        private const int WM_ACTIVATEAPP = 0x001C;

        [System.Runtime.InteropServices.DllImport("dwmapi.dll")]
        public static extern int DwmExtendFrameIntoClientArea(IntPtr hWnd, ref MARGINS pMarInset);
        [System.Runtime.InteropServices.DllImport("dwmapi.dll")]
        public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);
        [System.Runtime.InteropServices.DllImport("dwmapi.dll")]

        public static extern int DwmIsCompositionEnabled(ref int pfEnabled);
        [System.Runtime.InteropServices.DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
            );

        public struct MARGINS
        {
            public int leftWidth;
            public int rightWidth;
            public int topHeight;
            public int bottomHeight;
        }
        protected override CreateParams CreateParams
        {
            get
            {
                m_aeroEnabled = CheckAeroEnabled();
                CreateParams cp = base.CreateParams;
                if (!m_aeroEnabled)
                    cp.ClassStyle |= CS_DROPSHADOW; return cp;
            }
        }
        private bool CheckAeroEnabled()
        {
            if (Environment.OSVersion.Version.Major >= 6)
            {
                int enabled = 0; DwmIsCompositionEnabled(ref enabled);
                return (enabled == 1) ? true : false;
            }
            return false;
        }
        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case WM_NCPAINT:
                    if (m_aeroEnabled)
                    {
                        var v = 2;
                        DwmSetWindowAttribute(this.Handle, 2, ref v, 4);
                        MARGINS margins = new MARGINS()
                        {
                            bottomHeight = 1,
                            leftWidth = 0,
                            rightWidth = 0,
                            topHeight = 0
                        }; DwmExtendFrameIntoClientArea(this.Handle, ref margins);
                    }
                    break;
                default: break;
            }
            base.WndProc(ref m);
            if (m.Msg == WM_NCHITTEST && (int)m.Result == HTCLIENT) m.Result = (IntPtr)HTCAPTION;
        }
        #endregion shadow
        public int key=1;
        public Page p;
        List<JkerResult> resultList = new List<JkerResult>();
        public FindPage()
        {
            InitializeComponent();
            m_aeroEnabled = false;
            dropdown_more.Hide();                  
        }

        private void clickClose(object sender, EventArgs e)
        {
            p.callReset();            
            this.Hide();
        }
        private void moveClose(object sender, MouseEventArgs e)
        {
            rbgColor.setPictureBox(pb_close, 169, 169, 169);

        }

        private void leaveClose(object sender, EventArgs e)
        {
            pb_close.BackColor = Color.Transparent;
        }       

        private void checkChange(object sender, EventArgs e)
        {
            resultList.Clear();
            p.callReset();
            if (rb_name.Checked)
            {                
                dropdown_more.Hide();
                p.callFind(resultList, Support.checkFormat.regexYourNameV4, false);
                p.callFind(resultList, Support.checkFormat.regexYourNameV3, false);
                p.callFind(resultList, Support.checkFormat.regexYourNameV2, false);
                p.callFind(resultList,Support.checkFormat.regexYourNameV1,false);
                
            }
            if(rb_date.Checked)
            {
                dropdown_more.Hide();
                p.callFind(resultList, Support.checkFormat.regexDate, false);
            }
            if(rb_phone.Checked)
            {
                dropdown_more.Hide();
                p.callFind(resultList, Support.checkFormat.regexPhone, false);
            }
            if (rb_card.Checked)
            {                
                dropdown_more.Hide();
                p.callFind(resultList, Support.checkFormat.regexCard, false);
            }
            if (rb_file.Checked)
            {
                dropdown_more.Clear();
                dropdown_more.AddItem("Loại File");
                dropdown_more.AddItem("Video");
                dropdown_more.AddItem("Âm thanh");
                dropdown_more.AddItem("Hình ảnh");
                dropdown_more.AddItem("Văn bản");
                dropdown_more.AddItem("Nén");
                dropdown_more.selectedIndex = 0;
                dropdown_more.Show();
            }
            if (rb_ip.Checked)
            {
                dropdown_more.Clear();
                dropdown_more.AddItem("Loại IP");
                dropdown_more.AddItem("IPv4");
                dropdown_more.AddItem("Ipv6");
                dropdown_more.selectedIndex = 0;
                dropdown_more.Show();
            }
            if (rb_mail.Checked)
            {
                dropdown_more.Clear();
                dropdown_more.AddItem("Loại Hòm thư");
                dropdown_more.AddItem("Tất cả");
                dropdown_more.AddItem("Gmail");
                dropdown_more.AddItem("Yahoo");
                dropdown_more.selectedIndex = 0;
                dropdown_more.Show();
            }
            if (rb_money.Checked)
            {
                dropdown_more.Clear();
                dropdown_more.AddItem("Loại Tiền tệ");
                dropdown_more.AddItem("Việt Nam");
                dropdown_more.AddItem("Mỹ");
                dropdown_more.AddItem("Anh");
                dropdown_more.AddItem("Trung");
                dropdown_more.AddItem("Nhật");
                dropdown_more.selectedIndex = 0;
                dropdown_more.Show();
            }
            if (rb_url.Checked)
            {
                dropdown_more.Hide();
                p.callFind(resultList, Support.checkFormat.regexURL, false);
            }
            resultList = resultList.OrderBy(x => x.indexInLine).ToList();
            fillData(resultList);
        }
        private void fillData(List<JkerResult> resultList)
        {
            tb_result.Rows.Clear();
            int i = 1;
            foreach(var item in resultList)
            {
                item.serial = i;
                tb_result.Rows.Add(i,item.value);
                i++;
            }            
        }

        private void clickCell(object sender, DataGridViewCellEventArgs e)
        {
            try
            {                                
                int serial = Convert.ToInt32(tb_result.Rows[e.RowIndex].Cells[0].Value);
                JkerResult result = resultList.Single(x => x.serial == serial);
                p.callResetBgFound(resultList);
                p.tb_content.Select(result.indexInLine, result.lengthInLine);
                p.tb_content.SelectionBackColor = Color.LightGray;
                p.tb_content.ScrollToCaret();
            }
            catch(Exception ex) { }
        }

        private void click_select(object sender, EventArgs e)
        {
            resultList.Clear();
            p.callReset();
            if (rb_file.Checked)
            {
                switch(dropdown_more.selectedIndex)
                {
                    case 1: p.callFind(resultList, Support.checkFormat.regexVideo, false);break;                            
                    case 2: p.callFind(resultList, Support.checkFormat.regexMusic, false);break;
                    case 3: p.callFind(resultList, Support.checkFormat.regexImage, false);break;
                    case 4: p.callFind(resultList, Support.checkFormat.regexDocument, false); break;
                    case 5: p.callFind(resultList, Support.checkFormat.regexCompression, false); break;
                }
            }
            if (rb_ip.Checked)
            {
                switch (dropdown_more.selectedIndex)
                {
                    case 1: p.callFind(resultList, Support.checkFormat.regexIpV4, false); break;
                    case 2: p.callFind(resultList, Support.checkFormat.regexIpV6, false); break;                    
                }
            }
            if (rb_mail.Checked)
            {
                switch (dropdown_more.selectedIndex)
                {
                    case 1: p.callFind(resultList, Support.checkFormat.regexMail, false); break;
                    case 2: p.callFind(resultList, Support.checkFormat.regexEmail, false); break;
                    case 3: p.callFind(resultList, Support.checkFormat.regexYahoo, false); break;                    
                }
            }
            if (rb_money.Checked)
            {
                switch (dropdown_more.selectedIndex)
                {
                    case 1: p.callFind(resultList, Support.checkFormat.regexVietNameseMoney, false); break;
                    case 2: p.callFind(resultList, Support.checkFormat.regexUsaMoney, false); break;
                    case 3: p.callFind(resultList, Support.checkFormat.regexEUMoney, false); break;
                    case 4: p.callFind(resultList, Support.checkFormat.regexChineseMoney, false); break;
                    case 5: p.callFind(resultList, Support.checkFormat.regexJapaneseMoneyV1, false); p.callFind(resultList, Support.checkFormat.regexJapaneseMoneyV2, false); break;
                }
            }
            resultList = resultList.OrderBy(x => x.indexInLine).ToList();
            fillData(resultList);
        }
    }
}
