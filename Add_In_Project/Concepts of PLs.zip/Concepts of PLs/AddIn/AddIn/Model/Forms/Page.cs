﻿using AddIn.Model.ThisProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddIn.Model.Forms
{
    public partial class Page : Form
    {
        public string Path;
        public string NameNotEdit;
        public string NameEdit;
        public bool isEdit;
        public string TextContent;      
        public Page()
        {
            InitializeComponent();
        }

        private void changeContent(object sender, EventArgs e)
        {
            this.Text = NameEdit;
            TextContent = tb_content.Text;
            isEdit = true;                     
        }
        public void callUndo()
        {
            tb_content.Undo();
        }
        public void callRedo()
        {
            tb_content.Redo();
        }
        public void callCopy()
        {
            tb_content.Copy();
        }
        public void callCut()
        {
            tb_content.Cut();
        }
        public void callPaste()
        {            
            tb_content.Paste();
        }
        public void callSelectAll()
        {
            tb_content.SelectAll();
        }
        public void callFont()
        {
            FontDialog fontDialog = new FontDialog();
            DialogResult dialogMain = fontDialog.ShowDialog();
            if (dialogMain == DialogResult.OK)
            {
                //thay đổi font cho đoạn văn bản được bôi đen
                if (tb_content.SelectedText.Length > 0)
                {
                    tb_content.SelectionFont = fontDialog.Font;
                }
                //nếu không chọn thì thay đổi font cho tất cả
                else
                {
                    tb_content.SelectAll();
                    tb_content.Font = fontDialog.Font;
                    //using (StreamReader sr = new StreamReader(System.AppDomain.CurrentDomain.BaseDirectory + "Setting.txt"))
                    //{
                    //    Task<string> Text = sr.ReadToEndAsync();
                    //    settingNewPage(JkerStr.getName(folder.FileName), folder.FileName, Text.Result);
                    //}
                    tb_content.DeselectAll();
                }
                tb_content.Focus();
            }
        }
        public void callReset()
        {
            FontDialog fontDialog = new FontDialog();
            tb_content.SelectAll();
            tb_content.SelectionBackColor = Color.White;
            tb_content.DeselectAll();
        }
        public void callResetBgFound(List<JkerResult> resultList)
        {
            foreach(var item in resultList)
            {
                tb_content.Select(item.indexInLine, item.lengthInLine);
                tb_content.SelectionBackColor = System.Drawing.Color.Gray;
            }            
            tb_content.DeselectAll();
        }
        public void callColor()
        {
            ColorDialog colorDialog = new ColorDialog();
            DialogResult dialogMain = colorDialog.ShowDialog();
            if (dialogMain == DialogResult.OK)
            {                
                if (tb_content.SelectedText.Length > 0)
                {
                    tb_content.SelectionColor = colorDialog.Color;                    
                }                
                else
                {
                    tb_content.SelectAll();
                    tb_content.ForeColor = colorDialog.Color;
                    tb_content.DeselectAll();
                }
                tb_content.Focus();
            }
        }
        public List<JkerResult> callFind(List<JkerResult> resultList, string strRegex, bool blnIgnorCase = true)
        {
            try
            {
                Regex objRegex;
                int i = resultList.Count+1;
                // Create object
                if (blnIgnorCase)
                {
                    objRegex = new Regex(strRegex, RegexOptions.IgnoreCase);
                }
                else
                {
                    objRegex = new Regex(strRegex);
                }
                // Find
                using (StringReader reader = new StringReader(tb_content.Text))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        foreach (Match objMatch in objRegex.Matches(line))
                        {
                            foreach(var item in JkerStr.arrIndexOf(tb_content.Text, objMatch.ToString()))
                            {
                                if (resultList.FindAll(x => x.indexInLine == item.index).Count > 0)
                                    continue;
                                bool addOk = true;
                                foreach(var itm in resultList)
                                {
                                    int itmLastIndex = itm.indexInLine + itm.lengthInLine;
                                    int itemLastIndex = item.index + item.length;
                                    if(itm.indexInLine<=item.index&&itemLastIndex<=itmLastIndex)
                                    {
                                        addOk = false;
                                    }
                                    if(itm.indexInLine>=item.index && itemLastIndex>=itm.indexInLine && itemLastIndex<=itmLastIndex)
                                    {
                                        addOk = false;
                                    }
                                    if (itm.indexInLine <= item.index && item.index<=itmLastIndex && itemLastIndex > itmLastIndex)
                                    {
                                        addOk = false;
                                    }
                                }
                                if(addOk==true)
                                {
                                    tb_content.Select(item.index, objMatch.Length);
                                    tb_content.SelectionBackColor = System.Drawing.Color.Gray;
                                    resultList.Add(new JkerResult { serial = i, value = objMatch.ToString(), indexInLine = item.index, lengthInLine = objMatch.Length, isChoice = false });
                                    i++;
                                    break;
                                }                                
                            }                                                        
                            
                        }
                    }
                }                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Processing error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return resultList;
        }
    }
}
