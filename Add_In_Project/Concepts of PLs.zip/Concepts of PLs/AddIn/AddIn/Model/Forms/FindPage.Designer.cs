﻿namespace AddIn.Model.Forms
{
    partial class FindPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FindPage));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.pn_bg_top = new System.Windows.Forms.Panel();
            this.pb_close = new System.Windows.Forms.PictureBox();
            this.lb_title = new System.Windows.Forms.Label();
            this.pn_bg_left = new System.Windows.Forms.Panel();
            this.dropdown_more = new Bunifu.Framework.UI.BunifuDropdown();
            this.rb_card = new System.Windows.Forms.RadioButton();
            this.rb_file = new System.Windows.Forms.RadioButton();
            this.rb_money = new System.Windows.Forms.RadioButton();
            this.rb_ip = new System.Windows.Forms.RadioButton();
            this.rb_url = new System.Windows.Forms.RadioButton();
            this.rb_mail = new System.Windows.Forms.RadioButton();
            this.rb_phone = new System.Windows.Forms.RadioButton();
            this.rb_date = new System.Windows.Forms.RadioButton();
            this.rb_name = new System.Windows.Forms.RadioButton();
            this.pn_bg_fill = new System.Windows.Forms.Panel();
            this.tb_result = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.Stt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Value = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Func = new System.Windows.Forms.DataGridViewImageColumn();
            this.pn_bg_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_close)).BeginInit();
            this.pn_bg_left.SuspendLayout();
            this.pn_bg_fill.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tb_result)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 0;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.pn_bg_top;
            this.bunifuDragControl1.Vertical = true;
            // 
            // pn_bg_top
            // 
            this.pn_bg_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pn_bg_top.Controls.Add(this.pb_close);
            this.pn_bg_top.Controls.Add(this.lb_title);
            this.pn_bg_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pn_bg_top.Location = new System.Drawing.Point(0, 0);
            this.pn_bg_top.Name = "pn_bg_top";
            this.pn_bg_top.Size = new System.Drawing.Size(605, 25);
            this.pn_bg_top.TabIndex = 0;
            // 
            // pb_close
            // 
            this.pb_close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pb_close.Dock = System.Windows.Forms.DockStyle.Right;
            this.pb_close.Image = ((System.Drawing.Image)(resources.GetObject("pb_close.Image")));
            this.pb_close.Location = new System.Drawing.Point(579, 0);
            this.pb_close.Name = "pb_close";
            this.pb_close.Size = new System.Drawing.Size(26, 25);
            this.pb_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pb_close.TabIndex = 6;
            this.pb_close.TabStop = false;
            this.pb_close.Click += new System.EventHandler(this.clickClose);
            this.pb_close.MouseLeave += new System.EventHandler(this.leaveClose);
            this.pb_close.MouseMove += new System.Windows.Forms.MouseEventHandler(this.moveClose);
            // 
            // lb_title
            // 
            this.lb_title.BackColor = System.Drawing.Color.Transparent;
            this.lb_title.Dock = System.Windows.Forms.DockStyle.Left;
            this.lb_title.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_title.Location = new System.Drawing.Point(0, 0);
            this.lb_title.Name = "lb_title";
            this.lb_title.Size = new System.Drawing.Size(130, 25);
            this.lb_title.TabIndex = 0;
            this.lb_title.Text = "Find";
            this.lb_title.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pn_bg_left
            // 
            this.pn_bg_left.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pn_bg_left.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pn_bg_left.Controls.Add(this.dropdown_more);
            this.pn_bg_left.Controls.Add(this.rb_card);
            this.pn_bg_left.Controls.Add(this.rb_file);
            this.pn_bg_left.Controls.Add(this.rb_money);
            this.pn_bg_left.Controls.Add(this.rb_ip);
            this.pn_bg_left.Controls.Add(this.rb_url);
            this.pn_bg_left.Controls.Add(this.rb_mail);
            this.pn_bg_left.Controls.Add(this.rb_phone);
            this.pn_bg_left.Controls.Add(this.rb_date);
            this.pn_bg_left.Controls.Add(this.rb_name);
            this.pn_bg_left.Dock = System.Windows.Forms.DockStyle.Right;
            this.pn_bg_left.Location = new System.Drawing.Point(475, 25);
            this.pn_bg_left.Name = "pn_bg_left";
            this.pn_bg_left.Size = new System.Drawing.Size(130, 422);
            this.pn_bg_left.TabIndex = 1;
            // 
            // dropdown_more
            // 
            this.dropdown_more.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(206)))), ((int)(((byte)(219)))));
            this.dropdown_more.BorderRadius = 0;
            this.dropdown_more.DisabledColor = System.Drawing.Color.White;
            this.dropdown_more.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dropdown_more.ForeColor = System.Drawing.Color.Black;
            this.dropdown_more.Items = new string[] {
        "Loại thông tin",
        "Tên riêng",
        "Ngày tháng",
        "Số điện thoại",
        "Thẻ tín dụng",
        "Hòm thư",
        "Tiền tệ",
        "File",
        "URL",
        "IP"};
            this.dropdown_more.Location = new System.Drawing.Point(0, 393);
            this.dropdown_more.Margin = new System.Windows.Forms.Padding(0);
            this.dropdown_more.Name = "dropdown_more";
            this.dropdown_more.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(206)))), ((int)(((byte)(219)))));
            this.dropdown_more.onHoverColor = System.Drawing.Color.DarkGray;
            this.dropdown_more.selectedIndex = 0;
            this.dropdown_more.Size = new System.Drawing.Size(128, 27);
            this.dropdown_more.TabIndex = 12;
            this.dropdown_more.onItemSelected += new System.EventHandler(this.click_select);
            // 
            // rb_card
            // 
            this.rb_card.Dock = System.Windows.Forms.DockStyle.Top;
            this.rb_card.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.rb_card.FlatAppearance.BorderSize = 2;
            this.rb_card.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_card.Location = new System.Drawing.Point(0, 232);
            this.rb_card.Margin = new System.Windows.Forms.Padding(0);
            this.rb_card.Name = "rb_card";
            this.rb_card.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.rb_card.Size = new System.Drawing.Size(128, 29);
            this.rb_card.TabIndex = 11;
            this.rb_card.TabStop = true;
            this.rb_card.Text = "Card";
            this.rb_card.UseVisualStyleBackColor = true;
            this.rb_card.CheckedChanged += new System.EventHandler(this.checkChange);
            // 
            // rb_file
            // 
            this.rb_file.Dock = System.Windows.Forms.DockStyle.Top;
            this.rb_file.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_file.Location = new System.Drawing.Point(0, 203);
            this.rb_file.Margin = new System.Windows.Forms.Padding(0);
            this.rb_file.Name = "rb_file";
            this.rb_file.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.rb_file.Size = new System.Drawing.Size(128, 29);
            this.rb_file.TabIndex = 10;
            this.rb_file.TabStop = true;
            this.rb_file.Text = "File";
            this.rb_file.UseVisualStyleBackColor = true;
            this.rb_file.CheckedChanged += new System.EventHandler(this.checkChange);
            // 
            // rb_money
            // 
            this.rb_money.Dock = System.Windows.Forms.DockStyle.Top;
            this.rb_money.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_money.Location = new System.Drawing.Point(0, 174);
            this.rb_money.Margin = new System.Windows.Forms.Padding(0);
            this.rb_money.Name = "rb_money";
            this.rb_money.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.rb_money.Size = new System.Drawing.Size(128, 29);
            this.rb_money.TabIndex = 9;
            this.rb_money.TabStop = true;
            this.rb_money.Text = "Tiền tệ";
            this.rb_money.UseVisualStyleBackColor = true;
            this.rb_money.CheckedChanged += new System.EventHandler(this.checkChange);
            // 
            // rb_ip
            // 
            this.rb_ip.Dock = System.Windows.Forms.DockStyle.Top;
            this.rb_ip.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_ip.Location = new System.Drawing.Point(0, 145);
            this.rb_ip.Margin = new System.Windows.Forms.Padding(0);
            this.rb_ip.Name = "rb_ip";
            this.rb_ip.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.rb_ip.Size = new System.Drawing.Size(128, 29);
            this.rb_ip.TabIndex = 8;
            this.rb_ip.TabStop = true;
            this.rb_ip.Text = "IP";
            this.rb_ip.UseVisualStyleBackColor = true;
            this.rb_ip.CheckedChanged += new System.EventHandler(this.checkChange);
            // 
            // rb_url
            // 
            this.rb_url.Dock = System.Windows.Forms.DockStyle.Top;
            this.rb_url.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_url.Location = new System.Drawing.Point(0, 116);
            this.rb_url.Margin = new System.Windows.Forms.Padding(0);
            this.rb_url.Name = "rb_url";
            this.rb_url.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.rb_url.Size = new System.Drawing.Size(128, 29);
            this.rb_url.TabIndex = 7;
            this.rb_url.TabStop = true;
            this.rb_url.Text = "URL";
            this.rb_url.UseVisualStyleBackColor = true;
            this.rb_url.CheckedChanged += new System.EventHandler(this.checkChange);
            // 
            // rb_mail
            // 
            this.rb_mail.Dock = System.Windows.Forms.DockStyle.Top;
            this.rb_mail.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_mail.Location = new System.Drawing.Point(0, 87);
            this.rb_mail.Margin = new System.Windows.Forms.Padding(0);
            this.rb_mail.Name = "rb_mail";
            this.rb_mail.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.rb_mail.Size = new System.Drawing.Size(128, 29);
            this.rb_mail.TabIndex = 6;
            this.rb_mail.TabStop = true;
            this.rb_mail.Text = "Hòm thư";
            this.rb_mail.UseVisualStyleBackColor = true;
            this.rb_mail.CheckedChanged += new System.EventHandler(this.checkChange);
            // 
            // rb_phone
            // 
            this.rb_phone.Dock = System.Windows.Forms.DockStyle.Top;
            this.rb_phone.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_phone.Location = new System.Drawing.Point(0, 58);
            this.rb_phone.Margin = new System.Windows.Forms.Padding(0);
            this.rb_phone.Name = "rb_phone";
            this.rb_phone.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.rb_phone.Size = new System.Drawing.Size(128, 29);
            this.rb_phone.TabIndex = 5;
            this.rb_phone.TabStop = true;
            this.rb_phone.Text = "Số điện thoại";
            this.rb_phone.UseVisualStyleBackColor = true;
            this.rb_phone.CheckedChanged += new System.EventHandler(this.checkChange);
            // 
            // rb_date
            // 
            this.rb_date.Dock = System.Windows.Forms.DockStyle.Top;
            this.rb_date.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_date.Location = new System.Drawing.Point(0, 29);
            this.rb_date.Margin = new System.Windows.Forms.Padding(0);
            this.rb_date.Name = "rb_date";
            this.rb_date.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.rb_date.Size = new System.Drawing.Size(128, 29);
            this.rb_date.TabIndex = 4;
            this.rb_date.TabStop = true;
            this.rb_date.Text = "Ngày tháng";
            this.rb_date.UseVisualStyleBackColor = true;
            this.rb_date.CheckedChanged += new System.EventHandler(this.checkChange);
            // 
            // rb_name
            // 
            this.rb_name.Dock = System.Windows.Forms.DockStyle.Top;
            this.rb_name.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_name.Location = new System.Drawing.Point(0, 0);
            this.rb_name.Margin = new System.Windows.Forms.Padding(0);
            this.rb_name.Name = "rb_name";
            this.rb_name.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.rb_name.Size = new System.Drawing.Size(128, 29);
            this.rb_name.TabIndex = 3;
            this.rb_name.TabStop = true;
            this.rb_name.Text = "Tên riêng";
            this.rb_name.UseVisualStyleBackColor = true;
            this.rb_name.CheckedChanged += new System.EventHandler(this.checkChange);
            // 
            // pn_bg_fill
            // 
            this.pn_bg_fill.Controls.Add(this.tb_result);
            this.pn_bg_fill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pn_bg_fill.Location = new System.Drawing.Point(0, 25);
            this.pn_bg_fill.Name = "pn_bg_fill";
            this.pn_bg_fill.Size = new System.Drawing.Size(475, 422);
            this.pn_bg_fill.TabIndex = 2;
            // 
            // tb_result
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tb_result.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.tb_result.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tb_result.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_result.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tb_result.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.tb_result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tb_result.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Stt,
            this.Value,
            this.Func});
            this.tb_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_result.DoubleBuffered = true;
            this.tb_result.EnableHeadersVisualStyles = false;
            this.tb_result.GridColor = System.Drawing.Color.DarkGray;
            this.tb_result.HeaderBgColor = System.Drawing.Color.DimGray;
            this.tb_result.HeaderForeColor = System.Drawing.Color.White;
            this.tb_result.Location = new System.Drawing.Point(0, 0);
            this.tb_result.Name = "tb_result";
            this.tb_result.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.tb_result.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.tb_result.RowHeadersVisible = false;
            this.tb_result.RowHeadersWidth = 4;
            this.tb_result.ShowCellErrors = false;
            this.tb_result.ShowRowErrors = false;
            this.tb_result.Size = new System.Drawing.Size(475, 422);
            this.tb_result.TabIndex = 0;
            this.tb_result.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.clickCell);
            // 
            // Stt
            // 
            this.Stt.HeaderText = "STT";
            this.Stt.Name = "Stt";
            this.Stt.ReadOnly = true;
            this.Stt.Width = 50;
            // 
            // Value
            // 
            this.Value.HeaderText = "Kết quả";
            this.Value.Name = "Value";
            this.Value.ReadOnly = true;
            this.Value.Width = 324;
            // 
            // Func
            // 
            this.Func.HeaderText = "Chức năng";
            this.Func.Image = ((System.Drawing.Image)(resources.GetObject("Func.Image")));
            this.Func.Name = "Func";
            this.Func.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Func.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // FindPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(605, 447);
            this.Controls.Add(this.pn_bg_fill);
            this.Controls.Add(this.pn_bg_left);
            this.Controls.Add(this.pn_bg_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FindPage";
            this.Text = "FindPage";
            this.pn_bg_top.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_close)).EndInit();
            this.pn_bg_left.ResumeLayout(false);
            this.pn_bg_fill.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tb_result)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.Panel pn_bg_top;
        private System.Windows.Forms.Label lb_title;
        private System.Windows.Forms.PictureBox pb_close;
        private System.Windows.Forms.Panel pn_bg_left;
        private System.Windows.Forms.RadioButton rb_name;
        private System.Windows.Forms.RadioButton rb_card;
        private System.Windows.Forms.RadioButton rb_file;
        private System.Windows.Forms.RadioButton rb_money;
        private System.Windows.Forms.RadioButton rb_ip;
        private System.Windows.Forms.RadioButton rb_url;
        private System.Windows.Forms.RadioButton rb_mail;
        private System.Windows.Forms.RadioButton rb_phone;
        private System.Windows.Forms.RadioButton rb_date;
        private Bunifu.Framework.UI.BunifuDropdown dropdown_more;
        private System.Windows.Forms.Panel pn_bg_fill;
        private Bunifu.Framework.UI.BunifuCustomDataGrid tb_result;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Value;
        private System.Windows.Forms.DataGridViewImageColumn Func;
    }
}