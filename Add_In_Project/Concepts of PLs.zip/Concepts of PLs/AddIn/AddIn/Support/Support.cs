﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using AddIn.Model;
namespace AddIn.Support
{
    class rbgColor
    {
        public static string btnResizeImg = System.AppDomain.CurrentDomain.BaseDirectory.Replace("\\bin\\Debug","")+@"\Data\Icon\Function\Restore (1).png";
        public static string btnMaximineImg = System.AppDomain.CurrentDomain.BaseDirectory.Replace("\\bin\\Debug", "") + @"\Data\Icon\Function\Maximize (4).png";
        public static void setBtnImageButton( Bunifu.Framework.UI.BunifuImageButton a,int one, int two,int three)
        {
            a.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(one)))), ((int)(((byte)(two)))), ((int)(((byte)(three)))));
            a.Update();
        }
        public static void setPanel( System.Windows.Forms.Panel a,int one,int two,int three)
        {
            a.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(one)))), ((int)(((byte)(two)))), ((int)(((byte)(three)))));
            a.Update();
        }
        public static void setLabel(System.Windows.Forms.Label a, int one, int two, int three)
        {
            a.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(one)))), ((int)(((byte)(two)))), ((int)(((byte)(three)))));
            a.Update();
        }
        public static void setPictureBox(System.Windows.Forms.PictureBox a, int one, int two, int three)
        {
            a.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(one)))), ((int)(((byte)(two)))), ((int)(((byte)(three)))));
            a.Update();
        }
    }
    //Phục vụ mỗi View Desktop
    class currentForm
    {
        public static void defaultBgColor(System.Windows.Forms.Panel one, System.Windows.Forms.Panel two, System.Windows.Forms.Panel three, System.Windows.Forms.Panel four, System.Windows.Forms.Panel five, System.Windows.Forms.Panel six, System.Windows.Forms.Panel seven,Panel eight, System.Windows.Forms.Panel a, System.Windows.Forms.Panel b, System.Windows.Forms.Panel c, System.Windows.Forms.Panel d, System.Windows.Forms.Panel e, System.Windows.Forms.Panel f, System.Windows.Forms.Panel g,Panel h)
        {
            one.BackColor = Color.Transparent;
            two.BackColor = Color.Transparent;
            three.BackColor = Color.Transparent;
            four.BackColor = Color.Transparent;
            five.BackColor = Color.Transparent;
            six.BackColor = Color.Transparent;
            seven.BackColor = Color.Transparent;
            eight.BackColor = Color.Transparent;
            a.Hide();
            b.Hide();
            c.Hide();
            d.Hide();
            e.Hide();
            f.Hide();
            g.Hide();
            h.Hide();
        }
    }
    //Check dữ liệu nhập vào
    class checkFormat
    {
        public static bool check(string phone,string regex)
        {
            if (Regex.IsMatch(phone, regex) == true)
                return true;
            return false;
        }
        #region Name              
            public static string regexYourNameV1 = (@"([QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+\s){3,5}");
            public static string regexYourNameV2 = @"[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+\s[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+\s[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+";
            public static string regexYourNameV3 = @"[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+\s[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+\s[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+\s[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+";
            public static string regexYourNameV4 = @"[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+\s[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+\s[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+\s[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+\s[QERTYUIOPASDGHKLXCVBNMÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶĐÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴ][ertyuiopasdfghklzxcvbnmàáâãèéêìíòóôõùúăđĩũơưăạảấầẩẫậắằẳẵặẹẻẽềềếểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]+";
        #endregion Name
            public static string regexDate = @"\b\d{1,2}\/\d{1,2}\/(\d{4}|\d{2})\b";
            public static string regexPhone = @"(05|03|01[2|6|8|9])+([0-9]{7,8})\b";
            public static string regexCard = @"(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})";
            public static string regexURL = @"(http|ftp|https)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?";
        #region File
            public static string regexVideo = @"([a-zA-Z0-9-_ ]{1,})\.(AVI|OGM|MPG|MP4|MPEG-4|3GP|MKV|MIDI|flv|avi|ogm|mp4|mpeg-4|3gp|mkv|wmv|flac|mov)";
            public static string regexMusic = @"([a-zA-Z0-9-_ ]{1,})\.(wav|flac|mp3|AAC|WMA|ogg|ac3|wav)";
            public static string regexImage = @"([a-zA-Z0-9-_ ]{1,})\.(JPEG|GIF|PNG|JPG|TIFF|BMP|jpeg|gif|png|jpg|tiff|bmp|jp2|ico|tga)";
            public static string regexDocument = @"([a-zA-Z0-9-_ ]{1,})\.(docx|html|odt|xls|xlsx|pdf|pps|ppsx|ppt|pptx|rtf|txt|xps|epub|fb2|lit|lrf|mobi|pdb|rb|tcr|PRC|json|css)";
            public static string regexCompression = @"([a-zA-Z0-9-_ ]{1,})\.(7z|ace|zip|rar|tar.gz|jar|tar|cab)";
        #endregion File
        #region Ip
            public static string regexIpV4 = @"(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])";
            public static string regexIpV6 = @"(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))";
        #endregion Ip
        #region Mail
            public static string regexMail = @"[a-z-A-Z]\w+@(yahoo|gmail)\.com(\.vn)?";
            public static string regexEmail = @"[a-z-A-Z]\w+@gmail\.com(\.vn)?";
            public static string regexYahoo = @"[a-z-A-Z]\w+@yahoo\.com(\.vn)?";
        #endregion Mail
        #region Money
            public static string regexVietNameseMoney = @"(([1-9](\.|\,)?\d+(\.|\,)?(\d+(\.|\,)?)+\d+)|[1-9]\d*)\s?(triệu đồng|đồng|Đồng|triệu vnd|Triệu Đồng|Triệu VNĐ|VND|VNĐ|tỷ đồng|Tỷ Đồng)";
            public static string regexUsaMoney = @"(([1-9](\.|\,)?\d+(\.|\,)?(\d+(\.|\,)?)+\d+)|[1-9]\d*)\s?(\$|USD|nghìn đô|triệu đô|tỷ đô|đô)";
            public static string regexEUMoney = @"(([1-9](\.|\,)?\d+(\.|\,)?(\d+(\.|\,)?)+\d+)|[1-9]\d*)\s?(\€|Euro|euro|nghìn bảng|triệu bảng|tỷ bảng|bảng)";
            public static string regexChineseMoney = @"(([1-9](\.|\,)?\d+(\.|\,)?(\d+(\.|\,)?)+\d+)|[1-9]\d*)\s?(\¥|CNY|nghìn tệ|triệu tệ|tỷ tệ|tệ|nghìn nhân dân tệ|triệu nhân dân tệ|tỷ nhân dân tệ|nhân dân tệ)";
            public static string regexJapaneseMoneyV1 = @"(([1-9](\.|\,)?\d+(\.|\,)?(\d+(\.|\,)?)+\d+)|[1-9]\d*)\s?(JPY|nghìn yên|triệu yên|tỷ yên|yên)";
            public static string regexJapaneseMoneyV2 = @"\¥(([1-9](\.|\,)?\d+(\.|\,)?(\d+(\.|\,)?)+\d+)|[1-9]\d*)\s?";
        #endregion Money
            public static string regexPass = @"([A-Za-z0-9_]{4,15})";
            public static string regexNumber = @"^[0-9]+$";
            public static string regexDouble = @"[+-]?([0-9]*[.])?[0-9]+";
    }    
}
